"""
Backend for the Gold & Bitcoin LSTM price predictor.

Loads two pre-trained Keras LSTM models (gold, bitcoin) along with the
MinMaxScaler each was trained with, pulls the most recent 30 trading days
of (Close, Volume) from yfinance, and returns a next-step price prediction.

Expected files in ./models/  (see models/README.md):
    gold_model.keras       gold_scaler.pkl
    bitcoin_model.keras    bitcoin_scaler.pkl
"""

import os
import joblib
from datetime import datetime, timedelta
from pathlib import Path
from typing import Literal

import numpy as np
import pandas as pd
import yfinance as yf
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from tensorflow import keras

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = BASE_DIR / "models"
FRONTEND_DIR = BASE_DIR.parent / "frontend"

# How many past trading days the model expects as input.
WINDOW_SIZE = 30

# Column order used during training. IMPORTANT: this must match the order
# of columns you fed into the scaler/model when training. Change if needed.
FEATURE_COLUMNS = ["Close", "Volume"]

# yfinance ticker symbols for each asset.
TICKERS = {
    "gold": "GC=F",       # Gold futures. Use "XAUUSD=X" if that's what you trained on.
    "bitcoin": "BTC-USD",
}

ASSET_LABELS = {
    "gold": "Gold",
    "bitcoin": "Bitcoin",
}

MODEL_FILES = {
    "gold": {
        "model": MODELS_DIR / "lstm_gold_model.keras",
        "model_fallback": MODELS_DIR / "lstm_gold_model.h5",
        "scaler": MODELS_DIR / "gold_scaler.pkl",
    },
    "bitcoin": {
        "model": MODELS_DIR / "lstm_bitcoin_model.keras",
        "model_fallback": MODELS_DIR / "lstm_bitcoin_model.h5",
        "scaler": MODELS_DIR / "btc_scaler.pkl",
    },
}

AssetName = Literal["gold", "bitcoin"]

# --------------------------------------------------------------------------
# App setup
# --------------------------------------------------------------------------

app = FastAPI(title="Gold & Bitcoin LSTM Predictor")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to your frontend domain in production
    allow_methods=["*"],
    allow_headers=["*"],
)

_models: dict = {}
_scalers: dict = {}


def _load_model(asset: AssetName):
    paths = MODEL_FILES[asset]
    model_path = paths["model"] if paths["model"].exists() else paths["model_fallback"]
    if not model_path.exists():
        raise FileNotFoundError(
            f"No model file found for '{asset}'. Expected {paths['model'].name} "
            f"or {paths['model_fallback'].name} in {MODELS_DIR}"
        )
    return keras.models.load_model(model_path)


def _load_scaler(asset: AssetName):
    scaler_path = MODEL_FILES[asset]["scaler"]
    if not scaler_path.exists():
        raise FileNotFoundError(
            f"No scaler file found for '{asset}'. Expected {scaler_path.name} in {MODELS_DIR}"
        )
    return joblib.load(scaler_path)


@app.on_event("startup")
def load_artifacts():
    """Load models/scalers once at startup instead of per-request."""
    for asset in TICKERS:
        try:
            _models[asset] = _load_model(asset)
            _scalers[asset] = _load_scaler(asset)
            print(f"[startup] Loaded model + scaler for '{asset}'")
        except FileNotFoundError as e:
            # Don't crash the whole server if one asset's files are missing yet;
            # that endpoint will just return a clear error until you add them.
            print(f"[startup] WARNING: {e}")


# --------------------------------------------------------------------------
# Data + prediction helpers
# --------------------------------------------------------------------------

def fetch_recent_data(ticker: str, window: int = WINDOW_SIZE) -> pd.DataFrame:
    """Download enough recent history to guarantee `window` trading days."""
    # Buffer for weekends/holidays (gold futures & stocks aren't traded 7 days/week;
    # crypto is, but the extra buffer doesn't hurt).
    lookback_days = window * 3 + 15
    start = datetime.utcnow() - timedelta(days=lookback_days)

    df = yf.download(ticker, start=start.strftime("%Y-%m-%d"), progress=False, auto_adjust=False)
    if df.empty:
        raise HTTPException(status_code=502, detail=f"yfinance returned no data for {ticker}")

    # yfinance sometimes returns MultiIndex columns for a single ticker; flatten if so.
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    df = df.dropna(subset=FEATURE_COLUMNS)
    if len(df) < window:
        raise HTTPException(
            status_code=502,
            detail=f"Only {len(df)} trading days available for {ticker}, need {window}",
        )
    return df.tail(window)


def predict_next_price(asset: AssetName, df: pd.DataFrame) -> float:
    model = _models.get(asset)
    scaler = _scalers.get(asset)
    if model is None or scaler is None:
        raise HTTPException(
            status_code=503,
            detail=f"Model/scaler for '{asset}' not loaded. Add the files to backend/models/ and restart.",
        )

    raw_features = df[FEATURE_COLUMNS].values  # shape (window, n_features)
    scaled = scaler.transform(raw_features)
    x = scaled.reshape(1, WINDOW_SIZE, len(FEATURE_COLUMNS))

    pred_scaled = model.predict(x, verbose=0)
    pred_scaled_value = float(np.ravel(pred_scaled)[0])

    # Inverse-transform: the scaler was fit on all FEATURE_COLUMNS together,
    # so we reconstruct a full-width row (predicted Close + last known Volume)
    # before calling inverse_transform, then take the Close column back out.
    dummy_row = np.zeros((1, len(FEATURE_COLUMNS)))
    dummy_row[0, 0] = pred_scaled_value          # Close is column 0
    dummy_row[0, 1:] = scaled[-1, 1:]            # reuse last scaled Volume, etc.
    inv = scaler.inverse_transform(dummy_row)
    predicted_close = float(inv[0, 0])
    return predicted_close


class PredictionResponse(BaseModel):
    asset: str
    label: str
    ticker: str
    last_date: str
    last_close: float
    predicted_date: str
    predicted_close: float
    history_dates: list[str]
    history_close: list[float]


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

@app.get("/api/predict/{asset}", response_model=PredictionResponse)
def predict(asset: AssetName):
    if asset not in TICKERS:
        raise HTTPException(status_code=404, detail="Unknown asset")

    ticker = TICKERS[asset]
    df = fetch_recent_data(ticker)
    predicted_close = predict_next_price(asset, df)

    last_date = df.index[-1]
    predicted_date = last_date + timedelta(days=1)

    return PredictionResponse(
        asset=asset,
        label=ASSET_LABELS[asset],
        ticker=ticker,
        last_date=last_date.strftime("%Y-%m-%d"),
        last_close=float(df["Close"].iloc[-1]),
        predicted_date=predicted_date.strftime("%Y-%m-%d"),
        predicted_close=predicted_close,
        history_dates=[d.strftime("%Y-%m-%d") for d in df.index],
        history_close=[float(v) for v in df["Close"].values],
    )


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "models_loaded": {asset: asset in _models for asset in TICKERS},
    }


# --------------------------------------------------------------------------
# Serve the frontend (single-service deployment)
# --------------------------------------------------------------------------

if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

    @app.get("/")
    def index():
        return FileResponse(FRONTEND_DIR / "index.html")
