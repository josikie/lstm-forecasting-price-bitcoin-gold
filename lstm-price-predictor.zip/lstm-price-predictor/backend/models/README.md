# File model & scaler

✅ File kamu sudah dicek dan sudah ditaruh di sini:

```
lstm_gold_model.h5      gold_scaler.pkl
lstm_bitcoin_model.h5   btc_scaler.pkl
```

Yang sudah dikonfirmasi dari isi filenya:

- **Scaler**: `MinMaxScaler` (feature_range 0–1), di-fit pada 2 kolom
  `['Close', 'Volume']` dalam urutan itu — cocok dengan `FEATURE_COLUMNS` di
  `main.py`. Disimpan pakai **joblib** (bukan pickle biasa), jadi `main.py`
  pakai `joblib.load()`.
- **Model**: `Sequential` → `LSTM(50, return_sequences=True)` → `Dropout(0.2)`
  → `LSTM(50)` → `Dropout(0.2)` → `Dense(1, linear)`. Input shape `(30, 2)` —
  cocok dengan `WINDOW_SIZE=30` dan 2 fitur.
- Output model = 1 angka (Close yang sudah di-scale), diinverse-transform
  pakai trik "dummy row" di `predict_next_price()` — ini sudah pas untuk
  kasus scaler gabungan seperti punya kamu.

Kesimpulan: tidak perlu ubah apa-apa di `main.py`, tinggal jalankan.

## Kalau ganti model nanti

- Pakai scaler terpisah untuk fitur (X) dan target (y) → sesuaikan fungsi
  `predict_next_price()`, jangan pakai trik "dummy row".
- Pakai fitur lain selain Close & Volume → ubah `FEATURE_COLUMNS`.
- Window size bukan 30 → ubah `WINDOW_SIZE`.

Cara menyimpan scaler baru (kalau perlu):

```python
import joblib
joblib.dump(scaler, "gold_scaler.pkl")
```
