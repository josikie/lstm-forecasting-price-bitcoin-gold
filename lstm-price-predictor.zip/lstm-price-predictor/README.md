# Gold & Bitcoin LSTM Predictor

Website sederhana yang menampilkan prediksi harga emas & bitcoin dari 2 model
LSTM kamu. Backend (FastAPI) mengambil 30 hari data terbaru dari yfinance,
menjalankan model, lalu frontend menampilkannya sebagai dashboard.

```
lstm-price-predictor/
├── backend/
│   ├── main.py            # FastAPI app: fetch data, load model, prediksi
│   ├── requirements.txt
│   └── models/
│       ├── README.md      # penjelasan file apa yang harus ditaruh di sini
│       ├── gold_model.keras       <- taruh file kamu di sini
│       ├── gold_scaler.pkl        <- taruh file kamu di sini
│       ├── bitcoin_model.keras    <- taruh file kamu di sini
│       └── bitcoin_scaler.pkl     <- taruh file kamu di sini
├── frontend/
│   └── index.html         # dashboard, di-serve langsung oleh FastAPI di "/"
└── Dockerfile
```

## 1. Setup lokal

```bash
cd lstm-price-predictor/backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Taruh 4 file kamu (`gold_model.keras`, `gold_scaler.pkl`,
`bitcoin_model.keras`, `bitcoin_scaler.pkl`) ke dalam `backend/models/`.
Kalau format kamu `.h5`, itu juga didukung otomatis — cukup pakai nama
`gold_model.h5` / `bitcoin_model.h5`.

Jalankan:

```bash
uvicorn main:app --reload
```

Buka `http://localhost:8000` di browser — dashboard-nya langsung tampil
(FastAPI juga men-serve frontend-nya).

## 2. Cek dulu sebelum lanjut

Buka `backend/main.py` dan cocokkan dengan cara kamu training modelnya:

- `FEATURE_COLUMNS = ["Close", "Volume"]` — urutan ini harus sama persis
  dengan urutan kolom waktu kamu fit scaler & susun input training.
- `WINDOW_SIZE = 30` — sudah sesuai brief kamu, ubah kalau beda.
- `TICKERS` — `"GC=F"` untuk emas (futures) dan `"BTC-USD"` untuk bitcoin.
  Kalau training kamu pakai simbol lain (mis. `"XAUUSD=X"`), ganti di sini
  supaya konsisten dengan data training.
- Fungsi `predict_next_price()` — asumsinya 1 scaler gabungan untuk semua
  fitur (lihat `backend/models/README.md` untuk detail & alternatifnya).

## 3. Deploy online

### Opsi termudah: satu service (Railway / Render / Fly.io)

Repo ini sudah punya `Dockerfile` di root yang meng-copy backend + frontend
dan menjalankan satu server FastAPI yang meng-handle keduanya sekaligus.

**Railway:**
1. Push folder ini ke GitHub repo.
2. Railway → New Project → Deploy from GitHub repo.
3. Railway otomatis mendeteksi `Dockerfile`. Set env var `PORT` kalau perlu
   (biasanya otomatis).
4. Setelah deploy, domain Railway kamu langsung menampilkan dashboard.

**Render:**
1. Push ke GitHub.
2. New → Web Service → connect repo → pilih "Docker" sebagai environment.
3. Deploy.

Pastikan file model & scaler ikut ter-commit ke repo (atau upload manual ke
volume storage platform tsb — file `.keras`/`.h5` LSTM biasanya cukup kecil
untuk masuk git, tapi kalau besar pertimbangkan Git LFS).

### Opsi terpisah: backend & frontend beda service

Kalau mau frontend di Vercel/Netlify dan backend di Railway/Render terpisah:

1. Deploy folder `backend/` saja ke Railway/Render seperti di atas.
2. Di `frontend/index.html`, ubah baris:
   ```js
   const API_BASE = ""; 
   ```
   menjadi:
   ```js
   const API_BASE = "https://nama-backend-kamu.up.railway.app";
   ```
3. Deploy folder `frontend/` ke Vercel/Netlify sebagai static site.
4. Di `backend/main.py`, ganti `allow_origins=["*"]` dengan domain frontend
   kamu supaya lebih aman.

## 4. Batasan yang perlu kamu tahu

- yfinance kadang telat/berubah struktur data — kalau tiba-tiba error,
  cek dulu apakah `yf.download()` masih mengembalikan kolom yang sama.
- Model LSTM re-load setiap kali server restart (bukan setiap request),
  jadi startup pertama kali agak lambat kalau file model besar — normal.
- Ini prediksi dari model kamu sendiri, bukan saran finansial — perlu
  disclaimer itu kalau website-nya dilihat orang lain.
